/**
 * config.js
 * ------------------------------------------------------------------
 * دلته خپل ټول ثابت تنظیمات ولیکئ (چینلونه، جبري-ملضمشتراک چینل،
 * د بوټ نوم، ایعن).
 * ------------------------------------------------------------------
 */

module.exports = {
  // د بوټ عمومي معلومات (د .menu او externalAdReply لپاره)
  settings: {
    title: "🦂 TOOR LARAM TECH",
    description: "CODE. AUTOMATE. INNOVATE. — اتومات د خبرونو بوټ",
  },

  // د برانډ/پروفایل معلومات (.menu او .profile کمانډونه یې کاروي)
  brand: {
    name: "TOOR LARAM TECH",
    tagline: "Code. Automate. Innovate.",
    version: "1.0.0",
    developer: "TOOR LARAM TECH",
    emoji: "🦂",
  },

  // د بوټ د مالک شمېره (ادمین کمانډونو لپاره، لکه .source on/off)
  // بڼه: 93xxxxxxxxx (بې له + یا @s.whatsapp.net)
  ownerNumbers: [
    "93700000000", // <-- خپل شمېره دلته ولیکئ
  ],

  // د pairing لپاره شمېره (که پیرینګ کوډ کاروئ)
  pairingNumber: process.env.PAIRING_NUMBER || "",

  // جبري ګډون (Forced-Join) چینل — که کاروونکی غړی نه وي، بوټ به ورته
  // د غړیتوب/ملضمشتراک لینک درکوي او تر هغه به یې کمانډونه ونه چلیږي
  requiredChannel: {
    enabled: true,
    jid: "0029VbD1mQTIHphIkUriZk1I@newsletter", // د خپل چینل JID دلته ورکړئ
    inviteLink: "https://whatsapp.com/channel/0029VbD1mQTIHphIkUriZk1I",
    name: "زموږ اصلي چینل",
  },

  // درې جلا خپرېدونکي چینلونه، هر یو د خپلې ژبې لپاره
  channels: {
    pashto: {
      jid: "PASHTO_CHANNEL_JID@newsletter",
      link: "https://whatsapp.com/channel/PASHTO_LINK",
      label: "🇦🇫 پښتو خبرونه",
    },
    farsi: {
      jid: "FARSI_CHANNEL_JID@newsletter",
      link: "https://whatsapp.com/channel/FARSI_LINK",
      label: "🇮🇷 خبرهای فارسی",
    },
    english: {
      jid: "ENGLISH_CHANNEL_JID@newsletter",
      link: "https://whatsapp.com/channel/ENGLISH_LINK",
      label: "🌐 English News",
    },
  },

  // د خپرونو (ads/thumbnail) لپاره عکس/لینک
  thumbUrl: "https://i.imgur.com/your-thumb.jpg",

  // د .menu کمانډ عکس (لوکل فایل یا URL کیدی شي)
  menuImage: "./assets/menu.jpg",

  // هر څو دقیقې RSS بیا وګورل شي
  fetchIntervalMinutes: 10,

  // اختیاري: که د متن بیا-لیکنې (rewrite) لپاره د Anthropic API کاروئ
  // که دا نه ورکړئ، بوټ به ساده لنډیز (extractive) کاروي + سرچینه لینک
  anthropicApiKey: process.env.ANTHROPIC_API_KEY || "",
};
