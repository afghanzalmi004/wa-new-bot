const { loadSources, toggleSource, checkAllFeeds } = require("../lib/rss");
const { isOwner } = require("../lib/access");

/**
 * .source list | .source on <id> | .source off <id>
 */
async function handleSourceCommand(sock, jid, senderJid, args) {
  if (!isOwner(senderJid)) {
    await sock.sendMessage(jid, { text: "🚫 دا کمانډ یوازې د بوټ مالک لپاره دی." });
    return;
  }

  const sub = (args[0] || "").toLowerCase();

  if (sub === "list") {
    const sources = loadSources();
    const lines = sources.map(
      (s) => `${s.enabled ? "🟢" : "🔴"} ${s.id} — ${s.name} (${s.lang})`
    );
    await sock.sendMessage(jid, {
      text: `📋 *د سرچینو لیست*\n\n${lines.join("\n") || "هیڅ سرچینه نشته"}`,
    });
    return;
  }

  if (sub === "on" || sub === "off") {
    const id = args[1];
    if (!id) {
      await sock.sendMessage(jid, { text: "کاروني ډول: .source on <id>" });
      return;
    }
    const result = toggleSource(id, sub === "on");
    if (!result) {
      await sock.sendMessage(jid, { text: `❌ سرچینه '${id}' ونه موندل شوه.` });
      return;
    }
    await sock.sendMessage(jid, {
      text: `✅ '${result.name}' اوس ${sub === "on" ? "فعاله" : "غیرفعاله"} ده.`,
    });
    return;
  }

  await sock.sendMessage(jid, {
    text: "کاروني ډول:\n.source list\n.source on <id>\n.source off <id>",
  });
}

async function handleFetchCommand(sock, jid, senderJid) {
  if (!isOwner(senderJid)) {
    await sock.sendMessage(jid, { text: "🚫 دا کمانډ یوازې د بوټ مالک لپاره دی." });
    return;
  }
  await sock.sendMessage(jid, { text: "🔄 نوي خبرونه بیا چک کیږي..." });
  await checkAllFeeds(sock);
  await sock.sendMessage(jid, { text: "✅ بشپړ شو." });
}

module.exports = { handleSourceCommand, handleFetchCommand };
