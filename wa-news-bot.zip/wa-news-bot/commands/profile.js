const fs = require("fs");
const path = require("path");
const config = require("../config");
const { buildContextInfo, header, footer } = require("../lib/branding");
const { loadSources } = require("../lib/rss");

function formatUptime(seconds) {
  const h = Math.floor(seconds / 3600);
  const m = Math.floor((seconds % 3600) / 60);
  const s = Math.floor(seconds % 60);
  return `${h}ساعته ${m}دقیقې ${s}ثانیې`;
}

function countPublished() {
  try {
    const raw = fs.readFileSync(
      path.join(__dirname, "..", "data", "published.json"),
      "utf-8"
    );
    return JSON.parse(raw).length;
  } catch {
    return 0;
  }
}

function buildProfileText() {
  const b = config.brand;
  const sources = loadSources();
  const activeSources = sources.filter((s) => s.enabled).length;

  return `${header()}
🤖 *نوم:* ${b.name}
🏷️ *نعره:* ${b.tagline}
🔢 *نسخه:* ${b.version}
👨‍💻 *ډیزاین/جوړونکی:* ${b.developer}

📊 *ژوندۍ شمېرې*
› فعالې سرچینې: ${activeSources} / ${sources.length}
› خپاره شوي خبرونه (ټول وخت): ${countPublished()}
› فعاله موده: ${formatUptime(process.uptime())}

📡 *چینلونه*
› پښتو: ${config.channels.pashto.link}
› فارسي: ${config.channels.farsi.link}
› English: ${config.channels.english.link}
${footer()}`;
}

async function sendProfile(sock, jid) {
  const text = buildProfileText();
  const hasImage = config.menuImage && fs.existsSync(config.menuImage);
  const contextInfo = buildContextInfo();

  if (hasImage) {
    await sock.sendMessage(jid, {
      image: fs.readFileSync(config.menuImage),
      caption: text,
      contextInfo,
    });
  } else {
    await sock.sendMessage(jid, { text, contextInfo });
  }
}

module.exports = { sendProfile, buildProfileText };
