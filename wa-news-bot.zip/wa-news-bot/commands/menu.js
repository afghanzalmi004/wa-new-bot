const fs = require("fs");
const config = require("../config");
const { buildContextInfo, header, footer } = require("../lib/branding");

function buildMenuText() {
  const b = config.brand;

  return `${header()}
${b.tagline}
_نسخه: ${b.version}_

📡 *زموږ چینلونه*
› ${config.channels.pashto.label}
   ${config.channels.pashto.link}
› ${config.channels.farsi.label}
   ${config.channels.farsi.link}
› ${config.channels.english.label}
   ${config.channels.english.link}

🛠️ *عمومي کمانډونه*
› .menu / .help — دا مینو ښکاره کول
› .profile / .about — د بوټ پروفایل/معلومات
› .status — د بوټ حالت
› .ping — د ځواب سرعت

👑 *د ادمین کمانډونه*
› .source list — د ټولو سرچینو لیست
› .source on <id> — یوه سرچینه فعالول
› .source off <id> — یوه سرچینه غیرفعالول
› .fetch — همدا اوس نوي خبرونه چک کول

📢 لومړی زموږ اصلي چینل ته ملضمشتراک شئ:
${config.requiredChannel.inviteLink}
${footer()}`;
}

async function sendMenu(sock, jid) {
  const text = buildMenuText();
  const hasImage = config.menuImage && fs.existsSync(config.menuImage);
  const contextInfo = buildContextInfo();

  if (hasImage) {
    await sock.sendMessage(jid, {
      image: fs.readFileSync(config.menuImage),
      caption: text,
      contextInfo,
    });
  } else {
    await sock.sendMessage(jid, { text, contextInfo });
  }
}

module.exports = { sendMenu, buildMenuText };
