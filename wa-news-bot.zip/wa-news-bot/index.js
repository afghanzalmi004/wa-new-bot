/**
 * index.js
 * ------------------------------------------------------------------
 * د WhatsApp خبرونو بوټ - اصلي فایل | TOOR LARAM TECH
 * ------------------------------------------------------------------
 * چلول: node index.js
 * لومړی ځل به ستاسو د شمېرې (config.pairingNumber) لپاره pairing
 * کوډ چاپ کړي — هغه په WhatsApp > Linked Devices > Link with phone
 * number کې ولیکئ.
 * ------------------------------------------------------------------
 */

const {
  default: makeWASocket,
  useMultiFileAuthState,
  DisconnectReason,
  fetchLatestBaileysVersion,
  Browsers,
} = require("@whiskeysockets/baileys");
const pino = require("pino");
const chalk = require("chalk");
const cron = require("node-cron");
const readline = require("readline");

const config = require("./config");
const { sendMenu } = require("./commands/menu");
const { sendProfile } = require("./commands/profile");
const { handleSourceCommand, handleFetchCommand } = require("./commands/source");
const { checkAllFeeds } = require("./lib/rss");
const { requireJoin, joinReminderText } = require("./lib/access");

const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
const ask = (q) => new Promise((res) => rl.question(q, res));

// د cron د دوه ځله جدولېدو مخنیوی کله چې بوټ بیا وصل کیږي
let cronScheduled = false;

function printBanner() {
  const line = "━".repeat(46);
  console.log(chalk.greenBright(line));
  console.log(chalk.greenBright("  🦂  ") + chalk.bold.white("TOOR LARAM TECH") + chalk.cyanBright("  — News Bot"));
  console.log(chalk.cyanBright("      Code. Automate. Innovate."));
  console.log(chalk.greenBright(line));
}

async function clientstart() {
  const { state, saveCreds } = await useMultiFileAuthState("auth_info");
  const { version } = await fetchLatestBaileysVersion();

  const sock = makeWASocket({
    version,
    logger: pino({ level: "silent" }),
    printQRInTerminal: false,
    auth: state,
    browser: Browsers.macOS("Chrome"),
    syncFullHistory: false,
  });

  let pairingRequested = false;

  sock.ev.on("creds.update", saveCreds);

  sock.ev.on("connection.update", async (update) => {
    const { connection, lastDisconnect, qr } = update;

    // ---- Pairing Code (بدلون د QR پر ځای) ----
    // فکس: رسمي Baileys لارښود وايي چې pairing کوډ باید یوازې کله وغوښتل
    // شي چې سرور 'connecting' حالت ته ورسیږي (نه سمدلاسه له makeWASocket
    // وروسته) — پخوانی کوډ دا قاعده نه منله چې کله ناکله بشپړ ناکامي
    // (0% وصال) رامنځته کوله.
    if ((connection === "connecting" || qr) && !sock.authState.creds.registered && !pairingRequested) {
      pairingRequested = true;
      try {
        const number =
          config.pairingNumber ||
          (await ask("📱 خپله شمېره ولیکئ (لکه 93700000000): "));
        const cleanNumber = number.replace(/[^0-9]/g, "");
        const code = await sock.requestPairingCode(cleanNumber);
        const pretty = code.match(/.{1,4}/g)?.join("-") || code;
        console.log(chalk.greenBright(`🔗 ستاسو د Pairing کوډ دی: `) + chalk.bold.cyanBright(pretty));
        console.log(chalk.gray("   WhatsApp → Linked Devices → Link with phone number"));
      } catch (err) {
        console.error(chalk.red("❌ د Pairing کوډ غوښتنه پاتې راغله:"), err.message);
        pairingRequested = false;
      }
    }

    if (connection === "open") {
      if (rl && !rl.closed) rl.close();

      console.log(chalk.greenBright("✅ بوټ بریالی وصل شو! (TOOR LARAM TECH)"));

      // ابتدايي RSS چک د پیل پر مهال
      checkAllFeeds(sock).catch((e) => console.error(e.message));

      // مهالويش شوی چک هر config.fetchIntervalMinutes دقیقو کې — یوازې یو ځل جدول کیږي
      if (!cronScheduled) {
        cron.schedule(`*/${config.fetchIntervalMinutes} * * * *`, () => {
          checkAllFeeds(sock).catch((e) => console.error("د فید چک تېروتنه:", e.message));
        });
        cronScheduled = true;
      }
    }

    if (connection === "close") {
      const statusCode = lastDisconnect?.error?.output?.statusCode;
      const shouldReconnect = statusCode !== DisconnectReason.loggedOut;

      console.log(chalk.red("❌ اتصال بند شو:"), lastDisconnect?.error?.message || "");

      if (shouldReconnect) {
        console.log(chalk.yellow("🔄 بیا وصل کیدو هڅه کیږي..."));
        setTimeout(clientstart, 5000);
      } else {
        console.log(chalk.red("🚪 لاګ آوټ شوی؛ لطفاً 'auth_info' ړنګ او بیا pairing وکړئ."));
        process.exit(0);
      }
    }
  });

  // ---- د راغلو پیغامونو رواني ----
  sock.ev.on("messages.upsert", async ({ messages }) => {
    const msg = messages[0];
    if (!msg?.message || msg.key.fromMe) return;

    const jid = msg.key.remoteJid;
    const senderJid = msg.key.participant || msg.key.remoteJid;
    const text =
      msg.message.conversation ||
      msg.message.extendedTextMessage?.text ||
      msg.message.imageMessage?.caption ||
      "";

    if (!text.startsWith(".")) return;

    const [cmdRaw, ...args] = text.trim().split(/\s+/);
    const cmd = cmdRaw.slice(1).toLowerCase();

    // جبري-ملضمشتراک نرم یادونه (که فعاله وي)
    const allowed = await requireJoin(sock, senderJid);
    if (!allowed) {
      await sock.sendMessage(jid, { text: joinReminderText() });
      return;
    }

    const start = Date.now();

    try {
      switch (cmd) {
        case "menu":
        case "help":
          await sendMenu(sock, jid);
          break;

        case "profile":
        case "about":
          await sendProfile(sock, jid);
          break;

        case "status":
          await sock.sendMessage(jid, { text: "✅ بوټ فعال دی او سمه کار کوي." });
          break;

        case "ping": {
          const ms = Date.now() - start;
          await sock.sendMessage(jid, { text: `🏓 Pong! ${ms}ms` });
          break;
        }

        case "source":
          await handleSourceCommand(sock, jid, senderJid, args);
          break;

        case "fetch":
          await handleFetchCommand(sock, jid, senderJid);
          break;

        default:
          // ناپیژندلی کمانډ — غلی پاتې کیږي
          break;
      }
    } catch (err) {
      console.error("د کمانډ چلولو تېروتنه:", err);
      await sock.sendMessage(jid, { text: "⚠️ یوه تېروتنه رامنځته شوه." });
    }
  });

  return sock;
}

printBanner();
clientstart().catch((err) => {
  console.error(chalk.red("د پیل کولو تېروتنه:"), err);
  process.exit(1);
});
